package com.example.MultiGreenMaster.repository;

import com.example.MultiGreenMaster.entity.ChatMessageENT;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ChatMessageREP extends JpaRepository<ChatMessageENT, Long> {
    List<ChatMessageENT> findTop50ByRoomIdOrderByIdDesc(String roomId);
    Long countByRoomIdAndIdGreaterThan(String roomId, Long lastSeenId);
    List<ChatMessageENT> findTop1ByRoomIdOrderByIdDesc(String roomId);
}