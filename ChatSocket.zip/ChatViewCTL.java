package com.example.MultiGreenMaster.controller;

// package com.example.MultiGreenMaster.controller;
import com.example.MultiGreenMaster.entity.UserENT;
import com.example.MultiGreenMaster.service.UserSRV;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.SessionAttribute;

@Controller
@RequiredArgsConstructor
public class ChatViewCTL {

    private final UserSRV userSRV;

    @GetMapping("/chat")
    public String chat(@SessionAttribute(name="userId", required = false) Long userId, Model model) {
        UserENT loginUser = userSRV.getLoginUserById(userId);
        if (loginUser == null) return "redirect:/login"; // 프로젝트 로그인 경로에 맞춰 수정
        model.addAttribute("nickname", loginUser.getNickname());
        return "chat/chat";
    }
}
