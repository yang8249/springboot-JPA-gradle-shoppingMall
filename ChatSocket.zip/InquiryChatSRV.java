package com.example.MultiGreenMaster.service;

import com.example.MultiGreenMaster.dto.ChatMessageDTO;
import com.example.MultiGreenMaster.entity.ChatMessageENT;
import com.example.MultiGreenMaster.entity.ChatRoomENT;
import com.example.MultiGreenMaster.entity.UserENT;
import com.example.MultiGreenMaster.repository.ChatMessageREP;
import com.example.MultiGreenMaster.repository.ChatRoomREP;
import com.example.MultiGreenMaster.repository.UserREP;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;

@Service
@Transactional
@RequiredArgsConstructor
public class InquiryChatSRV {
    private final ChatMessageREP msgRep;
    private final UserREP userRep;
    private final ChatRoomREP roomRep;

    // 고객 방 생성 or 반환
    public ChatRoomENT
    ensureRoomForUser(Long userId) {
        String roomId = "inq-" + userId;
        return roomRep.findById(roomId).orElseGet(() -> {
            UserENT user = userRep.findById(userId).orElseThrow();
            ChatRoomENT r = ChatRoomENT.builder()
                    .id(roomId).user(user)
                    .lastMessageAt(null)
                    .lastMessagePreview(null)
                    .hasUnansweredByAdmin(false)
                    .build();
            return roomRep.save(r);
        });
    }

    public ChatMessageDTO saveMessage(Long senderId, String roomId, String content, boolean senderIsAdmin) {
        UserENT sender = userRep.findById(senderId).orElseThrow();
        ChatMessageENT saved = msgRep.save(ChatMessageENT.builder()
                .roomId(roomId)
                .sender(sender)
                .content(content)
                .sentAt(LocalDateTime.now())
                .build());

        // 방 메타 갱신
        ChatRoomENT room = roomRep.findById(roomId).orElseGet(() -> ensureRoomForUser(parseUserId(roomId)));
        room.setLastMessageAt(saved.getSentAt());
        room.setLastMessagePreview(content.length() > 50 ? content.substring(0, 50) : content);
        // 고객이 보냈으면 관리자 미응답 = true, 관리자가 보냈으면 false
        room.setHasUnansweredByAdmin(!senderIsAdmin);
        roomRep.save(room);

        return ChatMessageDTO.builder()
                .roomId(roomId)
                .senderNick(sender.getNickname())
                .content(content)
                .sentAt(saved.getSentAt().toString())
                .build();
    }

    public List<ChatMessageDTO> history(String roomId) {
        return msgRep.findTop50ByRoomIdOrderByIdDesc(roomId).stream()
                .sorted(Comparator.comparingLong(ChatMessageENT::getId))
                .map(m -> ChatMessageDTO.builder()
                        .roomId(roomId)
                        .senderNick(m.getSender() != null ? m.getSender().getNickname() : "unknown")
                        .content(m.getContent())
                        .sentAt(m.getSentAt().toString())
                        .build())
                .toList();
    }


    public List<ChatRoomENT> listRoomsForAdmin() {
        return roomRep.findAllByOrderByLastMessageAtDesc();
    }

    private Long parseUserId(String roomId) {
        // "inq-123" -> 123
        return Long.valueOf(roomId.substring(4));
    }
}

