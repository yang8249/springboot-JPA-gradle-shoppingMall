package com.example.MultiGreenMaster.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Getter @Setter @Builder
@NoArgsConstructor @AllArgsConstructor
@Table(name = "chat_message")
public class ChatMessageENT {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // 단일 글로벌 방이면 null/고정값으로 둬도 OK, 추후 다중방 확장 대비
    private String roomId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sender_id")
    private UserENT sender;

    @Column(nullable = false, length = 2000)
    private String content;

    @Column(nullable = false)
    private LocalDateTime sentAt;
}