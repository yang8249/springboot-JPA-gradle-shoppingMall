package com.example.MultiGreenMaster.repository;

import com.example.MultiGreenMaster.entity.ChatRoomENT;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ChatRoomREP extends JpaRepository<ChatRoomENT, String> {
    List<ChatRoomENT> findAllByOrderByLastMessageAtDesc();
}
