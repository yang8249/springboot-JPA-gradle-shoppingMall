package com.yang.shopping.model;

public enum RoleType {
	USER, ADMIN
}